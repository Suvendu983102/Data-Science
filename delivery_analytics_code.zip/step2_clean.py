import pandas as pd
import numpy as np

df = pd.read_pickle("/home/claude/delivery/raw.pkl")

# Step 2 -- Clean & derive delay metrics

before = len(df)
df = df.drop_duplicates()
print(f"Dropped {before - len(df)} exact duplicate rows")

df["warehouse"] = df["warehouse"].str.strip().str.upper()
WH_MAP = {
    "W01-DALLAS": "W01-Dallas", "W02-NEWARK": "W02-Newark", "W03-ATLANTA": "W03-Atlanta",
    "W04-CHICAGO": "W04-Chicago", "W05-SEATTLE": "W05-Seattle", "W06-PHOENIX": "W06-Phoenix",
    "W07-COLUMBUS": "W07-Columbus", "W08-DENVER": "W08-Denver",
}
df["warehouse"] = df["warehouse"].map(WH_MAP)

pending = df["actual_delivery_date"].isna().sum()
print(f"{pending} shipments have no recorded delivery event (still in-transit / lost) -- excluded from delay KPIs")
delivered = df.dropna(subset=["actual_delivery_date"]).copy()

delivered["order_date"] = pd.to_datetime(delivered["order_date"])
delivered["promised_delivery_date"] = pd.to_datetime(delivered["promised_delivery_date"])
delivered["actual_delivery_date"] = pd.to_datetime(delivered["actual_delivery_date"])

delivered["delay_days"] = (delivered["actual_delivery_date"] - delivered["promised_delivery_date"]).dt.days
delivered["is_delayed"] = (delivered["delay_days"] > 0).astype(int)
delivered["transit_days"] = (delivered["actual_delivery_date"] - delivered["order_date"]).dt.days
delivered["order_month"] = delivered["order_date"].values.astype("datetime64[M]")

SEASON_MAP = {12: "Holiday", 11: "Holiday", 1: "Winter", 2: "Winter",
              3: "Spring", 4: "Spring", 5: "Spring", 6: "Summer", 7: "Summer",
              8: "Summer", 9: "Fall", 10: "Fall"}
delivered["season"] = delivered["month"].map(SEASON_MAP)

print(f"\nDelivered & clean: {len(delivered):,} rows, {pending:,} pending excluded")
print(delivered[["warehouse", "carrier", "product_type", "delay_days", "is_delayed"]].head())

delivered.to_pickle("/home/claude/delivery/clean.pkl")

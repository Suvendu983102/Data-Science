import pandas as pd
import json

df = pd.read_pickle("/home/claude/delivery/clean.pkl")

# Step 3 -- Top-line delivery KPIs

total_shipments = len(df)
delayed = df["is_delayed"].sum()
on_time_pct = (1 - delayed / total_shipments) * 100
avg_delay_all = df["delay_days"].clip(lower=0).mean()
avg_delay_late = df.loc[df["is_delayed"] == 1, "delay_days"].mean()
avg_transit = df["transit_days"].mean()
severe_late = (df["delay_days"] >= 5).sum()
severe_late_pct = severe_late / total_shipments * 100

kpis = {
    "Total Delivered Shipments": f"{total_shipments:,}",
    "On-Time Delivery Rate": f"{on_time_pct:.2f}%",
    "Late Shipments": f"{delayed:,}",
    "Avg Delay (All Shipments)": f"{avg_delay_all:.2f} days",
    "Avg Delay (Late Shipments Only)": f"{avg_delay_late:.2f} days",
    "Avg Transit Time": f"{avg_transit:.2f} days",
    "Severely Late (5+ days)": f"{severe_late:,} ({severe_late_pct:.2f}%)",
}
for k, v in kpis.items():
    print(f"{k:<36}: {v}")

with open("/home/claude/delivery/kpis.json", "w") as f:
    json.dump(kpis, f)

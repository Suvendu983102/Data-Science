# Delivery Delay & Operations Analytics — Code

Run in order (each step reads the previous step's pickle output):

1. `step1_generate.py`   — generates the synthetic order/shipment/warehouse/carrier dataset (dirty data included)
2. `step2_clean.py`      — deduplicates, standardizes warehouse labels, excludes pending shipments, derives delay_days/is_delayed/season
3. `step3_kpis.py`       — computes top-line delivery KPIs (on-time rate, avg delay, severe lateness)
4. `step4_segments.py`   — delay rate by warehouse / carrier / product type / day of week / season, generates chart PNGs
5. `step5_hotspots.py`   — warehouse x carrier hotspot table, monthly trend chart, delay-rate heatmap
6. `step6_model.py`      — decision tree delay-risk model, confusion matrix, feature importances

Requires: pandas, numpy, matplotlib, scikit-learn
(`pip install pandas numpy matplotlib scikit-learn`)

Charts are written to a `charts/` subfolder relative to wherever you run the scripts from —
update the `CH` path at the top of steps 4, 5 and 6 if you move the files.

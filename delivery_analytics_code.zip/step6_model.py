import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score
from sklearn.preprocessing import OneHotEncoder

df = pd.read_pickle("/home/claude/delivery/clean.pkl")
CH = "/home/claude/delivery/charts"

# Step 6 -- Decision tree model to estimate delay risk from shipment attributes

FEATURES = ["warehouse", "carrier", "product_type", "dest_region", "day_of_week", "season"]
X_raw = df[FEATURES]
y = df["is_delayed"]

enc = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
X = enc.fit_transform(X_raw)
feature_names = enc.get_feature_names_out(FEATURES)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=7, stratify=y)

clf = DecisionTreeClassifier(max_depth=6, min_samples_leaf=40, random_state=7)
clf.fit(X_train, y_train)
y_pred = clf.predict(X_test)

acc = accuracy_score(y_test, y_pred)
prec = precision_score(y_test, y_pred)
rec = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)
print(f"Test accuracy:  {acc:.3f}")
print(f"Precision:      {prec:.3f}")
print(f"Recall:         {rec:.3f}")
print(f"F1 score:       {f1:.3f}")

cm = confusion_matrix(y_test, y_pred)
print("\nConfusion matrix [rows=actual, cols=predicted] (On-Time, Late):\n", cm)

fig, ax = plt.subplots(figsize=(5.5, 5))
im = ax.imshow(cm, cmap="Blues")
labels = ["On-Time", "Late"]
ax.set_xticks([0, 1]); ax.set_xticklabels(labels)
ax.set_yticks([0, 1]); ax.set_yticklabels(labels)
ax.set_xlabel("Predicted"); ax.set_ylabel("Actual")
ax.set_title("Delay-Risk Model: Confusion Matrix", fontsize=13, fontweight="bold")
for i in range(2):
    for j in range(2):
        ax.text(j, i, f"{cm[i, j]:,}", ha="center", va="center",
                color="white" if cm[i, j] > cm.max() / 2 else "black", fontsize=13)
plt.tight_layout()
plt.savefig(f"{CH}/confusion_matrix.png", dpi=150)
plt.close()

# Feature importance (top 10)
importances = pd.Series(clf.feature_importances_, index=feature_names).sort_values(ascending=False).head(10)
print("\nTop 10 feature importances:\n", importances)

fig, ax = plt.subplots(figsize=(9, 5.5))
ax.barh(importances.index[::-1], importances.values[::-1], color="#1C7293")
ax.set_title("Top 10 Feature Importances -- Delay Risk Model", fontsize=14, fontweight="bold")
ax.set_xlabel("Importance")
ax.grid(axis="x", alpha=0.3)
plt.tight_layout()
plt.savefig(f"{CH}/feature_importance.png", dpi=150)
plt.close()

metrics = {"accuracy": acc, "precision": prec, "recall": rec, "f1": f1}
import json
with open("/home/claude/delivery/model_metrics.json", "w") as f:
    json.dump(metrics, f)

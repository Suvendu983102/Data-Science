import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_pickle("/home/claude/delivery/clean.pkl")
CH = "/home/claude/delivery/charts"

# Step 4 -- Segment delay rate by warehouse, carrier, route, product, day, season

def delay_rate_table(group_col):
    t = (df.groupby(group_col)
         .agg(shipments=("order_id", "count"), late=("is_delayed", "sum"))
         .reset_index())
    t["delay_rate"] = t["late"] / t["shipments"] * 100
    return t.sort_values("delay_rate", ascending=False)

wh_perf = delay_rate_table("warehouse")
carrier_perf = delay_rate_table("carrier")
product_perf = delay_rate_table("product_type")
dow_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
dow_perf = delay_rate_table("day_of_week").set_index("day_of_week").reindex(dow_order).reset_index()
season_perf = delay_rate_table("season")

print("Warehouse:\n", wh_perf)
print("\nCarrier:\n", carrier_perf)
print("\nProduct type:\n", product_perf)
print("\nDay of week:\n", dow_perf)
print("\nSeason:\n", season_perf)

fig, ax = plt.subplots(figsize=(10, 5))
ax.barh(wh_perf["warehouse"], wh_perf["delay_rate"], color="#065A82")
ax.set_title("Delay Rate by Warehouse", fontsize=15, fontweight="bold")
ax.set_xlabel("Delay Rate (%)")
ax.invert_yaxis()
ax.grid(axis="x", alpha=0.3)
plt.tight_layout()
plt.savefig(f"{CH}/delay_by_warehouse.png", dpi=150)
plt.close()

fig, ax = plt.subplots(figsize=(9, 5))
ax.bar(carrier_perf["carrier"], carrier_perf["delay_rate"], color="#1C7293")
ax.set_title("Delay Rate by Carrier", fontsize=15, fontweight="bold")
ax.set_ylabel("Delay Rate (%)")
plt.xticks(rotation=20)
ax.grid(axis="y", alpha=0.3)
plt.tight_layout()
plt.savefig(f"{CH}/delay_by_carrier.png", dpi=150)
plt.close()

fig, ax = plt.subplots(figsize=(9, 5))
ax.bar(product_perf["product_type"], product_perf["delay_rate"], color="#3FBFA6")
ax.set_title("Delay Rate by Product Type", fontsize=15, fontweight="bold")
ax.set_ylabel("Delay Rate (%)")
ax.grid(axis="y", alpha=0.3)
plt.tight_layout()
plt.savefig(f"{CH}/delay_by_product.png", dpi=150)
plt.close()

fig, ax = plt.subplots(figsize=(10, 5))
ax.bar(dow_perf["day_of_week"], dow_perf["delay_rate"], color="#D9704F")
ax.set_title("Delay Rate by Day of Week (Order Placed)", fontsize=15, fontweight="bold")
ax.set_ylabel("Delay Rate (%)")
plt.xticks(rotation=20)
ax.grid(axis="y", alpha=0.3)
plt.tight_layout()
plt.savefig(f"{CH}/delay_by_dow.png", dpi=150)
plt.close()

fig, ax = plt.subplots(figsize=(8, 5))
ax.bar(season_perf["season"], season_perf["delay_rate"], color="#8A5FBF")
ax.set_title("Delay Rate by Season", fontsize=15, fontweight="bold")
ax.set_ylabel("Delay Rate (%)")
ax.grid(axis="y", alpha=0.3)
plt.tight_layout()
plt.savefig(f"{CH}/delay_by_season.png", dpi=150)
plt.close()

wh_perf.to_pickle(f"{CH}/../wh_perf.pkl")
carrier_perf.to_pickle(f"{CH}/../carrier_perf.pkl")
product_perf.to_pickle(f"{CH}/../product_perf.pkl")
dow_perf.to_pickle(f"{CH}/../dow_perf.pkl")
season_perf.to_pickle(f"{CH}/../season_perf.pkl")

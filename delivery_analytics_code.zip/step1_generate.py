import numpy as np
import pandas as pd
import random

random.seed(7)
np.random.seed(7)

# Step 1 -- Generate the raw dataset
# Simulates a merged order + shipment + warehouse + carrier + delivery-event
# export (with intentional dirty data) so the cleaning step is genuinely exercised.

N_ORDERS = 20000
START_DATE = pd.Timestamp("2024-01-01")
END_DATE = pd.Timestamp("2026-08-31")

WAREHOUSES = {
    "W01-Dallas": "Central", "W02-Newark": "East", "W03-Atlanta": "South",
    "W04-Chicago": "Central", "W05-Seattle": "West", "W06-Phoenix": "West",
    "W07-Columbus": "East", "W08-Denver": "South",
}
# Baseline congestion factor per warehouse (added transit variance)
WH_CONGESTION = {"W01-Dallas": 0.3, "W02-Newark": 0.9, "W03-Atlanta": 0.5,
                 "W04-Chicago": 0.6, "W05-Seattle": 0.4, "W06-Phoenix": 0.2,
                 "W07-Columbus": 1.1, "W08-Denver": 0.35}

CARRIERS = {
    "Carrier Alpha": {"promised_days": 3, "reliability": 0.90},
    "Carrier Beta":  {"promised_days": 2, "reliability": 0.78},
    "Carrier Gamma": {"promised_days": 4, "reliability": 0.95},
    "Carrier Delta": {"promised_days": 2, "reliability": 0.65},
    "Carrier Epsilon": {"promised_days": 5, "reliability": 0.97},
}
PRODUCT_TYPES = {
    "Electronics": 0.15, "Furniture": 0.55, "Apparel": 0.05,
    "Grocery": 0.20, "Pharma": 0.08, "Industrial": 0.45,
}
REGIONS = ["North", "South", "East", "West", "Central"]

warehouses_list = list(WAREHOUSES.keys())
carriers_list = list(CARRIERS.keys())
products_list = list(PRODUCT_TYPES.keys())

rows = []
for i in range(N_ORDERS):
    order_date = START_DATE + pd.Timedelta(days=int(np.random.uniform(0, (END_DATE - START_DATE).days)))
    warehouse = random.choice(warehouses_list)
    dest_region = random.choice(REGIONS)
    carrier = random.choices(carriers_list, weights=[0.28, 0.22, 0.18, 0.17, 0.15])[0]
    product = random.choices(products_list, weights=[0.22, 0.12, 0.25, 0.20, 0.11, 0.10])[0]

    promised_days = CARRIERS[carrier]["promised_days"]
    reliability = CARRIERS[carrier]["reliability"]
    congestion = WH_CONGESTION[warehouse]
    product_risk = PRODUCT_TYPES[product]

    dow = order_date.dayofweek  # 0=Mon..6=Sun
    weekend_penalty = 0.8 if dow >= 5 else 0.0
    month = order_date.month
    season_penalty = 1.4 if month in (11, 12) else (0.5 if month in (6, 7) else 0.0)

    # Expected extra transit days beyond "promised", driven by unreliability,
    # warehouse congestion, product handling risk, weekend dispatch, and season.
    base_extra = (1 - reliability) * 1.5 + congestion * 0.28 + product_risk * 0.55
    extra_days = np.random.exponential(scale=max(0.03, base_extra)) + weekend_penalty * 0.4 + season_penalty * 0.5
    noise = np.random.normal(0, 0.25)
    actual_transit_days = max(0.2, promised_days + extra_days + noise)

    promised_delivery_date = order_date + pd.Timedelta(days=promised_days)
    actual_delivery_date = order_date + pd.Timedelta(days=round(actual_transit_days, 2))
    if actual_delivery_date > END_DATE:
        actual_delivery_date = END_DATE

    # ~2% of shipments are still "in transit" / lost -> missing actual delivery
    is_missing = random.random() < 0.02

    rows.append({
        "order_id": f"ORD{i+1:06d}",
        "order_date": order_date.date(),
        "warehouse": random.choice([warehouse, warehouse.upper(), f" {warehouse} "]),  # dirty on purpose
        "dest_region": dest_region,
        "carrier": carrier,
        "product_type": product,
        "promised_delivery_date": promised_delivery_date.date(),
        "actual_delivery_date": actual_delivery_date.date() if not is_missing else None,
        "day_of_week": order_date.day_name(),
        "month": month,
    })

df = pd.DataFrame(rows)

# Inject ~3% exact duplicate rows (dirty data)
dupe_idx = df.sample(frac=0.03, random_state=7).index
df = pd.concat([df, df.loc[dupe_idx]], ignore_index=True)

print(f"Raw records: {len(df):,}")
print(df.head())
df.to_pickle("/home/claude/delivery/raw.pkl")

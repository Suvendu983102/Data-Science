import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

df = pd.read_pickle("/home/claude/delivery/clean.pkl")
CH = "/home/claude/delivery/charts"

# Step 5 -- Exploratory analysis: high-delay combinations and trend spikes

combo = (df.groupby(["warehouse", "carrier"])
         .agg(shipments=("order_id", "count"), late=("is_delayed", "sum"))
         .reset_index())
combo = combo[combo["shipments"] >= 50]  # ignore tiny combos
combo["delay_rate"] = combo["late"] / combo["shipments"] * 100
top_hotspots = combo.sort_values("delay_rate", ascending=False).head(10)
print("Top 10 warehouse x carrier hotspots:\n", top_hotspots)

monthly = (df.groupby("order_month")
           .agg(shipments=("order_id", "count"), late=("is_delayed", "sum"))
           .reset_index())
monthly["delay_rate"] = monthly["late"] / monthly["shipments"] * 100
monthly = monthly.sort_values("order_month")

fig, ax = plt.subplots(figsize=(11, 5))
ax.plot(monthly["order_month"], monthly["delay_rate"], marker="o", color="#D9704F", linewidth=2)
ax.set_title("Monthly Delay Rate Trend", fontsize=15, fontweight="bold")
ax.set_ylabel("Delay Rate (%)")
ax.grid(axis="y", alpha=0.3)
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(f"{CH}/monthly_delay_trend.png", dpi=150)
plt.close()

# Heatmap: warehouse x carrier delay rate
pivot = combo.pivot(index="warehouse", columns="carrier", values="delay_rate")
fig, ax = plt.subplots(figsize=(10, 6))
im = ax.imshow(pivot.values, cmap="YlOrRd", aspect="auto")
ax.set_xticks(range(len(pivot.columns)))
ax.set_xticklabels(pivot.columns, rotation=30, ha="right")
ax.set_yticks(range(len(pivot.index)))
ax.set_yticklabels(pivot.index)
for i in range(len(pivot.index)):
    for j in range(len(pivot.columns)):
        val = pivot.values[i, j]
        if not np.isnan(val):
            ax.text(j, i, f"{val:.0f}%", ha="center", va="center", fontsize=9,
                    color="white" if val > pivot.values[~np.isnan(pivot.values)].mean() else "black")
ax.set_title("Delay Rate Heatmap: Warehouse x Carrier", fontsize=14, fontweight="bold")
plt.colorbar(im, ax=ax, label="Delay Rate (%)")
plt.tight_layout()
plt.savefig(f"{CH}/hotspot_heatmap.png", dpi=150)
plt.close()

top_hotspots.to_pickle(f"{CH}/../top_hotspots.pkl")
monthly.to_pickle(f"{CH}/../monthly.pkl")

# Employee Attrition Analytics & Retention Insights — Code

Run in order (each step reads the previous step's pickle output):

1. `step1_generate.py`  — generates the synthetic HRIS dataset (2,000 employees, dirty data included)
2. `step2_clean.py`     — deduplicates, imputes missing performance ratings, standardizes labels, derives tenure bands
3. `step3_kpis.py`      — computes top-line and derived attrition KPIs
4. `step4_breakdowns.py` — attrition by department / tenure band / compensation band / performance, generates chart PNGs
5. `step5_regression.py` — logistic regression of attrition on tenure, comp band, performance, overtime, engagement
6. `step6_risk_segments.py` — scores active employees for flight risk, builds risk-segment donut chart

Requires: pandas, numpy, matplotlib, faker, statsmodels
(`pip install pandas numpy matplotlib faker statsmodels`)

Charts are written to a `charts/` subfolder relative to wherever you run the scripts from —
update the `CH` path at the top of steps 4 and 6 if you move the files.

import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import matplotlib.pyplot as plt

df = pd.read_pickle("/home/claude/attrition/clean.pkl")
CH = "/home/claude/attrition/charts"

# Step 6 -- Score ACTIVE employees with the fitted model to flag flight risk

model_df = df.copy()
model_df["comp_band_code"] = pd.Categorical(
    model_df["compensation_band"], categories=["Entry", "Mid", "Senior", "Lead"], ordered=True
)
formula = ("is_exited ~ tenure_years + C(comp_band_code, Treatment(reference='Lead')) "
           "+ performance_rating + overtime_hours_monthly + engagement_score")
logit_model = smf.logit(formula, data=model_df).fit(disp=0)

active = model_df[model_df["exit_status"] == "Active"].copy()
active["exit_risk_score"] = logit_model.predict(active)

bins = [0, 0.15, 0.35, 1.01]
labels = ["Low Risk", "Medium Risk", "High Risk"]
active["risk_segment"] = pd.cut(active["exit_risk_score"], bins=bins, labels=labels)

seg_counts = active["risk_segment"].value_counts().reindex(labels)
print("Active employees:", len(active))
print(seg_counts)

colors = {"Low Risk": "#3FBFA6", "Medium Risk": "#1C7293", "High Risk": "#D9704F"}
fig, ax = plt.subplots(figsize=(7, 7))
ax.pie(seg_counts.values, labels=seg_counts.index, autopct="%1.0f%%",
       colors=[colors[s] for s in seg_counts.index],
       wedgeprops={"width": 0.4, "edgecolor": "white"})
ax.set_title("Active Employee Flight-Risk Segments", fontsize=15, fontweight="bold")
plt.tight_layout()
plt.savefig(f"{CH}/risk_segments.png", dpi=150)
plt.close()

# High-risk department concentration
high_risk_by_dept = (active[active["risk_segment"] == "High Risk"]
                      .groupby("department").size().sort_values(ascending=False))
print("\nHigh-risk headcount by department:\n", high_risk_by_dept)

active.to_pickle("/home/claude/attrition/active_scored.pkl")
seg_counts.to_pickle("/home/claude/attrition/seg_counts.pkl")

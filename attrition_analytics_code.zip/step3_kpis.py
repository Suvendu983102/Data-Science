import pandas as pd

df = pd.read_pickle("/home/claude/attrition/clean.pkl")

# Step 3 -- Top-line KPIs & derived attrition metrics

total_employees = len(df)
total_exits = df["is_exited"].sum()
overall_attrition = total_exits / total_employees

early_exits = df["early_tenure_exit"].sum()
early_tenure_pop = (df["tenure_years"] < 1).sum() + early_exits  # exited-before-1yr + still-under-1yr actives
early_tenure_rate = early_exits / max(1, (df["tenure_years"] < 1).sum() + early_exits)

avg_tenure_active = df.loc[df["exit_status"] == "Active", "tenure_years"].mean()
avg_tenure_exited = df.loc[df["exit_status"] == "Exited", "tenure_years"].mean()
avg_engagement = df["engagement_score"].mean()
avg_overtime = df["overtime_hours_monthly"].mean()

# Annualized attrition rate: exits in the trailing 12 months / avg headcount
snapshot = pd.Timestamp("2026-09-01")
trailing_12mo_exits = df[(df["exit_date"] >= snapshot - pd.Timedelta(days=365)) & (df["is_exited"] == 1)].shape[0]
annual_attrition_rate = trailing_12mo_exits / total_employees

kpis = {
    "Total Employees (snapshot)": f"{total_employees:,}",
    "Total Exits (all time)": f"{total_exits:,}",
    "Overall Attrition Rate": f"{overall_attrition*100:.2f}%",
    "Trailing 12-Mo Attrition Rate": f"{annual_attrition_rate*100:.2f}%",
    "Early-Tenure (<1yr) Attrition Rate": f"{early_tenure_rate*100:.2f}%",
    "Avg Tenure (Active)": f"{avg_tenure_active:.2f} yrs",
    "Avg Tenure (Exited)": f"{avg_tenure_exited:.2f} yrs",
    "Avg Engagement Score": f"{avg_engagement:.2f} / 10",
    "Avg Monthly Overtime": f"{avg_overtime:.1f} hrs",
}
for k, v in kpis.items():
    print(f"{k:<36}: {v}")

import json
with open("/home/claude/attrition/kpis.json", "w") as f:
    json.dump(kpis, f)

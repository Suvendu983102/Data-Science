import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf

df = pd.read_pickle("/home/claude/attrition/clean.pkl")

# Step 5 -- Logistic regression: which factors are significantly associated
# with attrition, holding the others constant?

model_df = df.copy()
model_df["comp_band_code"] = pd.Categorical(
    model_df["compensation_band"], categories=["Entry", "Mid", "Senior", "Lead"], ordered=True
)

formula = ("is_exited ~ tenure_years + C(comp_band_code, Treatment(reference='Lead')) "
           "+ performance_rating + overtime_hours_monthly + engagement_score")
logit_model = smf.logit(formula, data=model_df).fit(disp=0)
print(logit_model.summary())

# Odds ratios for interpretability
odds_ratios = np.exp(logit_model.params)
conf = np.exp(logit_model.conf_int())
conf.columns = ["OR_2.5%", "OR_97.5%"]
result_table = pd.concat([odds_ratios.rename("Odds Ratio"), conf,
                           logit_model.pvalues.rename("p-value")], axis=1)
print("\nOdds ratios:\n", result_table.round(3))

result_table.to_pickle("/home/claude/attrition/odds_ratios.pkl")

with open("/home/claude/attrition/logit_summary.txt", "w") as f:
    f.write(str(logit_model.summary()))

import pandas as pd
import numpy as np

df = pd.read_pickle("/home/claude/attrition/raw.pkl")

# Step 2 -- Data quality checks & cleaning
# No names, emails, or other direct identifiers are collected -- employee_id
# is the only key, keeping the dataset minimal per data-protection guidance.

before = len(df)
df = df.drop_duplicates()
print(f"Dropped {before - len(df)} exact duplicate rows")

df["department"] = df["department"].str.strip().str.title()
df["department"] = df["department"].replace({"Hr": "HR"})

missing_perf = df["performance_rating"].isna().sum()
median_perf = df["performance_rating"].median()
df["performance_rating"] = df["performance_rating"].fillna(median_perf)
print(f"Imputed {missing_perf} missing performance ratings with median ({median_perf:.0f})")

df["hire_date"] = pd.to_datetime(df["hire_date"])
df["exit_date"] = pd.to_datetime(df["exit_date"])

TENURE_BINS = [0, 1, 3, 5, 10, 100]
TENURE_LABELS = ["<1 yr", "1-3 yrs", "3-5 yrs", "5-10 yrs", "10+ yrs"]
df["tenure_band"] = pd.cut(df["tenure_years"], bins=TENURE_BINS, labels=TENURE_LABELS, right=False)

df["is_exited"] = (df["exit_status"] == "Exited").astype(int)
df["early_tenure_exit"] = ((df["is_exited"] == 1) & (df["tenure_years"] < 1)).astype(int)
df["exit_month"] = df["exit_date"].values.astype("datetime64[M]")

print(f"\nClean dataset: {len(df):,} rows, {df['employee_id'].nunique():,} unique employees")
print(df[["department", "role", "tenure_band", "compensation_band",
          "performance_rating", "exit_status"]].head())

df.to_pickle("/home/claude/attrition/clean.pkl")

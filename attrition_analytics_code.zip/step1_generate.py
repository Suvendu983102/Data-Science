# Install/import dependencies (Colab already has most of these)
# !pip install -q faker statsmodels --break-system-packages > /dev/null 2>&1

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from faker import Faker
import random

random.seed(42)
np.random.seed(42)
fake = Faker()
Faker.seed(42)

plt.rcParams["figure.facecolor"] = "white"
plt.rcParams["axes.spines.top"] = False
plt.rcParams["axes.spines.right"] = False

# Step 1 -- Generate the raw dataset
# Simulates an HRIS export (with intentional dirty data: duplicates, missing
# values, inconsistent labels) so the cleaning step is genuinely exercised.

N_EMPLOYEES = 2000
SNAPSHOT_DATE = pd.Timestamp("2026-09-01")

DEPARTMENTS = {
    "Engineering": ["Software Engineer", "QA Engineer", "DevOps Engineer", "Engineering Manager"],
    "Sales": ["Sales Executive", "Account Manager", "Sales Manager"],
    "Customer Support": ["Support Associate", "Support Team Lead"],
    "Marketing": ["Marketing Associate", "Content Strategist", "Marketing Manager"],
    "Finance": ["Financial Analyst", "Accountant", "Finance Manager"],
    "HR": ["HR Associate", "Recruiter", "HR Manager"],
    "Operations": ["Operations Analyst", "Operations Manager"],
}
COMP_BANDS = ["Entry", "Mid", "Senior", "Lead"]
COMP_BAND_RANGE = {"Entry": (28000, 42000), "Mid": (42000, 65000),
                   "Senior": (65000, 95000), "Lead": (95000, 140000)}

rows = []
for i in range(N_EMPLOYEES):
    dept = random.choice(list(DEPARTMENTS.keys()))
    role = random.choice(DEPARTMENTS[dept])
    comp_band = random.choices(COMP_BANDS, weights=[0.35, 0.35, 0.2, 0.1])[0]
    lo, hi = COMP_BAND_RANGE[comp_band]
    salary = round(np.random.uniform(lo, hi), 2)

    # Hire date spread over the last ~8 years; tenure-at-snapshot drives risk
    hire_date = SNAPSHOT_DATE - pd.Timedelta(days=int(np.random.uniform(30, 8 * 365.25)))
    tenure_at_snapshot = (SNAPSHOT_DATE - hire_date).days / 365.25

    performance = np.clip(np.round(np.random.normal(3.2, 0.9)), 1, 5)
    overtime_hours = max(0, np.random.normal(6, 5))
    projects_count = max(1, int(np.random.poisson(3)))
    engagement_score = np.clip(np.round(np.random.normal(6.5, 1.8), 1), 1, 10)

    # Synthetic attrition logic: higher risk for short tenure, low pay band,
    # low performance, high overtime, low engagement.
    risk = (
        -0.35 * tenure_at_snapshot
        + (1.1 if comp_band == "Entry" else 0.4 if comp_band == "Mid" else 0.0)
        + (0.8 if performance <= 2 else 0.0)
        + 0.05 * overtime_hours
        - 0.18 * engagement_score
        + np.random.normal(0, 1.1)
    )
    exit_prob = 1 / (1 + np.exp(-(risk - 1.0)))
    exited = np.random.random() < exit_prob

    exit_date = None
    tenure_years = tenure_at_snapshot
    if exited:
        # Exit date falls somewhere between hire and snapshot, skewed toward
        # earlier tenure for lower engagement/comp employees (early quits).
        frac = np.clip(np.random.beta(1.5, 3.0), 0.02, 1.0)
        exit_date = hire_date + pd.Timedelta(days=int(frac * (SNAPSHOT_DATE - hire_date).days))
        tenure_years = max(0.02, (exit_date - hire_date).days / 365.25)

    rows.append({
        "employee_id": f"EMP{i+1:05d}",
        "department": random.choice([dept, dept.upper(), f" {dept} "]),  # dirty on purpose
        "role": role,
        "hire_date": hire_date.date(),
        "tenure_years": tenure_years,
        "compensation_band": comp_band,
        "annual_salary": salary,
        "performance_rating": int(performance) if random.random() > 0.015 else None,
        "overtime_hours_monthly": round(overtime_hours, 1),
        "projects_count": projects_count,
        "engagement_score": engagement_score,
        "exit_status": "Exited" if exited else "Active",
        "exit_date": exit_date.date() if exit_date is not None else None,
    })

emp_df = pd.DataFrame(rows)

# Inject ~2.5% exact duplicate rows (dirty data)
dupe_idx = emp_df.sample(frac=0.025, random_state=42).index
emp_df = pd.concat([emp_df, emp_df.loc[dupe_idx]], ignore_index=True)

print(f"Raw records: {len(emp_df):,}")
print(emp_df.head())
emp_df.to_pickle("/home/claude/attrition/raw.pkl")

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

df = pd.read_pickle("/home/claude/attrition/clean.pkl")
CH = "/home/claude/attrition/charts"

# Step 4 -- Attrition by department, tenure band, compensation band, performance

dept_perf = (df.groupby("department")
             .agg(headcount=("employee_id", "count"), exits=("is_exited", "sum"))
             .reset_index())
dept_perf["attrition_rate"] = dept_perf["exits"] / dept_perf["headcount"] * 100
dept_perf = dept_perf.sort_values("attrition_rate", ascending=False)

fig, ax = plt.subplots(figsize=(10, 5))
ax.barh(dept_perf["department"], dept_perf["attrition_rate"], color="#065A82")
ax.set_title("Attrition Rate by Department", fontsize=15, fontweight="bold")
ax.set_xlabel("Attrition Rate (%)")
ax.invert_yaxis()
ax.grid(axis="x", alpha=0.3)
plt.tight_layout()
plt.savefig(f"{CH}/attrition_by_department.png", dpi=150)
plt.close()
print(dept_perf)

tenure_perf = (df.groupby("tenure_band", observed=True)
               .agg(headcount=("employee_id", "count"), exits=("is_exited", "sum"))
               .reset_index())
tenure_perf["attrition_rate"] = tenure_perf["exits"] / tenure_perf["headcount"] * 100

fig, ax = plt.subplots(figsize=(9, 5))
ax.bar(tenure_perf["tenure_band"], tenure_perf["attrition_rate"], color="#1C7293")
ax.set_title("Attrition Rate by Tenure Band", fontsize=15, fontweight="bold")
ax.set_ylabel("Attrition Rate (%)")
ax.grid(axis="y", alpha=0.3)
plt.tight_layout()
plt.savefig(f"{CH}/attrition_by_tenure.png", dpi=150)
plt.close()
print(tenure_perf)

comp_perf = (df.groupby("compensation_band", observed=True)
             .agg(headcount=("employee_id", "count"), exits=("is_exited", "sum"),
                  avg_salary=("annual_salary", "mean"))
             .reindex(["Entry", "Mid", "Senior", "Lead"]).reset_index())
comp_perf["attrition_rate"] = comp_perf["exits"] / comp_perf["headcount"] * 100

fig, ax = plt.subplots(figsize=(9, 5))
ax.bar(comp_perf["compensation_band"], comp_perf["attrition_rate"], color="#3FBFA6")
ax.set_title("Attrition Rate by Compensation Band", fontsize=15, fontweight="bold")
ax.set_ylabel("Attrition Rate (%)")
ax.grid(axis="y", alpha=0.3)
plt.tight_layout()
plt.savefig(f"{CH}/attrition_by_comp_band.png", dpi=150)
plt.close()
print(comp_perf)

perf_perf = (df.groupby("performance_rating")
             .agg(headcount=("employee_id", "count"), exits=("is_exited", "sum"))
             .reset_index())
perf_perf["attrition_rate"] = perf_perf["exits"] / perf_perf["headcount"] * 100

monthly_exits = (df.dropna(subset=["exit_month"])
                 .groupby("exit_month").size().reset_index(name="exits")
                 .sort_values("exit_month"))

fig, ax = plt.subplots(figsize=(11, 5))
ax.plot(monthly_exits["exit_month"], monthly_exits["exits"], marker="o", color="#D9704F", linewidth=2)
ax.set_title("Monthly Exit Volume", fontsize=15, fontweight="bold")
ax.set_ylabel("Exits")
ax.grid(axis="y", alpha=0.3)
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(f"{CH}/monthly_exits.png", dpi=150)
plt.close()
print(perf_perf)

# Workload indicator: overtime hours, active vs exited
overtime_cmp = df.groupby("exit_status")["overtime_hours_monthly"].mean()
engagement_cmp = df.groupby("exit_status")["engagement_score"].mean()
print("\nAvg monthly overtime by status:\n", overtime_cmp)
print("\nAvg engagement score by status:\n", engagement_cmp)

dept_perf.to_pickle(f"{CH}/../dept_perf.pkl")
tenure_perf.to_pickle(f"{CH}/../tenure_perf.pkl")
comp_perf.to_pickle(f"{CH}/../comp_perf.pkl")

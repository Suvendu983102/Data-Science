# E-commerce Sales & Customer Insights Dashboard

**Capstone Project — Mindenious Edutech Data Science Program**

## Objective
Analyze sales, customer behavior, products, and geography to identify revenue drivers and business opportunities.

## Project Structure
```
ecommerce_project/
├── data/
│   ├── generate_data.py      # synthetic data generator (customers, products, locations, orders)
│   ├── customers.csv
│   ├── products.csv
│   ├── locations.csv
│   └── orders.csv
├── notebooks/
│   └── analysis.py           # full analysis pipeline (clean -> KPIs -> cohort -> RFM -> insights)
├── dashboard/
│   └── app.py                # Streamlit interactive dashboard
├── outputs/                  # generated tables consumed by the dashboard
│   ├── clean_orders.csv
│   ├── kpis.csv
│   ├── monthly_trend.csv
│   ├── cohort_retention.csv
│   ├── customer_rfm.csv
│   ├── product_performance.csv
│   ├── category_performance.csv
│   └── region_performance.csv
├── requirements.txt
└── README.md
```

## How to Run
```bash
pip install -r requirements.txt

# 1. Generate the raw dataset (customers, products, locations, orders)
python data/generate_data.py

# 2. Run the cleaning + KPI + cohort + RFM analysis pipeline
python notebooks/analysis.py

# 3. Launch the interactive dashboard
streamlit run dashboard/app.py
```

## Approach (mapped to the brief)
1. **Combine tables** — `analysis.py` merges order, customer, product, and location tables into one working dataframe.
2. **Clean data** — drops exact duplicate order lines, removes orders with missing customer IDs, imputes missing quantities with the median, standardizes inconsistent category text (whitespace/casing), and treats refunds as negative revenue.
3. **KPIs** — total revenue, total orders, average order value (AOV), margin %, repeat-customer rate, refund rate, and active customers (see `outputs/kpis.csv`).
4. **Cohort & trend analysis** — monthly revenue/order trend (`monthly_trend.csv`) and a signup-month cohort retention table (`cohort_retention.csv`). Customers are also segmented using RFM (Recency, Frequency, Monetary) scoring into High-Value / Loyal / At-Risk / Low-Value buckets (`customer_rfm.csv`).
5. **Patterns** — top products, category performance (including margin % and refund rate), and regional performance are broken out separately.
6. **Dashboard** — the Streamlit app (`dashboard/app.py`) provides date-range, region, category, and RFM-segment filters, KPI cards, a monthly trend chart, top-products and category charts, a regional bar chart, an RFM segment breakdown, and a closing set of data-backed recommendations.

## Key Findings (from the generated sample data)
- **Beauty** and **Home & Kitchen** are the top-revenue categories and also carry healthy margins — worth prioritizing.
- **Electronics** and **Books** have the highest refund rates — worth a listing/quality audit.
- **South** and **North** regions lead in both revenue and customer count; **East** and **West** lag despite similar AOV, suggesting a marketing-reach gap rather than a pricing problem.
- Roughly 40% of the customer base falls into the "At-Risk" or "Low-Value" RFM segments — a clear target for a win-back campaign.
- Repeat-customer rate is strong, and AOV sits around $165 — a small free-shipping threshold just above this could nudge basket sizes up.

## Data Note
Since no proprietary company data was provided, this project uses a **synthetically generated
dataset** (`data/generate_data.py`) built to realistically mimic an e-commerce system — including
intentionally messy elements (duplicate rows, missing values, inconsistent category text) so the
cleaning step in the brief is genuinely exercised. To adapt this project to a real dataset (e.g.
Kaggle's "Online Retail" or "Olist Brazilian E-commerce" datasets), simply replace the CSVs in
`data/` with matching column names, or adjust the column mapping in `analysis.py`.

## Suggested Stack (per brief)
- **Python** (pandas, numpy) for data preparation and modeling
- **Streamlit** + **Plotly** for the interactive dashboard/UI layer
- **Git/GitHub** for version control (recommended: commit this folder as its own repo)

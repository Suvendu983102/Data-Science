"""
E-commerce Sales & Customer Insights — core analysis pipeline.

Steps:
 1. Load & merge order, customer, product, location tables
 2. Clean duplicates, missing values, refunds, inconsistent categories
 3. Build KPIs: revenue, orders, AOV, repeat-customer rate, margin
 4. Cohort (monthly signup cohort) + monthly revenue trend
 5. Customer segmentation (RFM-style: recency, frequency, monetary)
 6. Top products, underperforming categories, high-value customers, regional patterns
 7. Save all outputs as CSVs for the dashboard to consume

Run: python analysis.py
"""

import pandas as pd
import numpy as np
from pathlib import Path

DATA_DIR = Path("/home/claude/ecommerce_project/data")
OUT_DIR = Path("/home/claude/ecommerce_project/outputs")
OUT_DIR.mkdir(exist_ok=True)

# ---------------------------------------------------------------
# 1. LOAD
# ---------------------------------------------------------------
orders = pd.read_csv(DATA_DIR / "orders.csv", parse_dates=["order_date"])
customers = pd.read_csv(DATA_DIR / "customers.csv", parse_dates=["signup_date"])
products = pd.read_csv(DATA_DIR / "products.csv")
locations = pd.read_csv(DATA_DIR / "locations.csv")

print(f"Raw rows -> orders: {len(orders)}, customers: {len(customers)}, "
      f"products: {len(products)}, locations: {len(locations)}")

# ---------------------------------------------------------------
# 2. CLEAN
# ---------------------------------------------------------------
# 2a. Drop exact duplicate order lines
before = len(orders)
orders = orders.drop_duplicates()
print(f"Dropped {before - len(orders)} exact duplicate rows")

# 2b. Drop rows with missing customer_id (can't attribute revenue)
orders = orders.dropna(subset=["customer_id"])

# 2c. Fill missing quantity with the median quantity (robust to outliers)
median_qty = orders["quantity"].median()
orders["quantity"] = orders["quantity"].fillna(median_qty)

# 2d. Standardize product category text (strip whitespace, title-case)
products["category"] = products["category"].str.strip().str.title()

# 2e. Compute line revenue; refunded lines contribute negative revenue
orders["line_amount"] = orders["quantity"] * orders["unit_price"]
orders["net_amount"] = np.where(orders["is_refunded"], -orders["line_amount"], orders["line_amount"])

# ---------------------------------------------------------------
# 3. MERGE
# ---------------------------------------------------------------
df = (orders
      .merge(customers, on="customer_id", how="left")
      .merge(products[["product_id", "product_name", "category", "unit_cost"]],
             on="product_id", how="left", suffixes=("", "_prod"))
      .merge(locations, on="location_id", how="left"))

df["order_month"] = df["order_date"].values.astype("datetime64[M]")
df["signup_month"] = df["signup_date"].values.astype("datetime64[M]")
df["cost_amount"] = np.where(df["is_refunded"], 0, df["quantity"] * df["unit_cost"])
df["margin_amount"] = df["net_amount"] - df["cost_amount"]

df.to_csv(OUT_DIR / "clean_orders.csv", index=False)

# ---------------------------------------------------------------
# 4. TOP-LINE KPIs
# ---------------------------------------------------------------
total_revenue = df["net_amount"].sum()
total_orders = df["order_id"].nunique()
aov = total_revenue / total_orders
total_margin = df["margin_amount"].sum()
margin_pct = total_margin / total_revenue

orders_per_customer = df.groupby("customer_id")["order_id"].nunique()
repeat_customer_rate = (orders_per_customer > 1).mean()

kpis = pd.DataFrame([{
    "total_revenue": round(total_revenue, 2),
    "total_orders": total_orders,
    "avg_order_value": round(aov, 2),
    "total_margin": round(total_margin, 2),
    "margin_pct": round(margin_pct * 100, 2),
    "repeat_customer_rate_pct": round(repeat_customer_rate * 100, 2),
    "active_customers": df["customer_id"].nunique(),
    "refund_rate_pct": round(df["is_refunded"].mean() * 100, 2),
}])
kpis.to_csv(OUT_DIR / "kpis.csv", index=False)
print("\n=== TOP-LINE KPIs ===")
print(kpis.T)

# ---------------------------------------------------------------
# 5. MONTHLY TREND
# ---------------------------------------------------------------
monthly = (df.groupby("order_month")
             .agg(revenue=("net_amount", "sum"),
                  orders=("order_id", "nunique"),
                  customers=("customer_id", "nunique"))
             .reset_index())
monthly["aov"] = monthly["revenue"] / monthly["orders"]
monthly.to_csv(OUT_DIR / "monthly_trend.csv", index=False)

# ---------------------------------------------------------------
# 6. COHORT ANALYSIS (monthly signup cohort revenue retention)
# ---------------------------------------------------------------
cohort = (df.groupby(["signup_month", "order_month"])
            .agg(revenue=("net_amount", "sum"), customers=("customer_id", "nunique"))
            .reset_index())
cohort["cohort_index"] = (
    (cohort["order_month"].dt.year - cohort["signup_month"].dt.year) * 12 +
    (cohort["order_month"].dt.month - cohort["signup_month"].dt.month)
)
cohort_pivot = cohort.pivot_table(index="signup_month", columns="cohort_index",
                                   values="customers", aggfunc="sum").fillna(0)
cohort_pivot.to_csv(OUT_DIR / "cohort_retention.csv")

# ---------------------------------------------------------------
# 7. RFM CUSTOMER SEGMENTATION
# ---------------------------------------------------------------
snapshot_date = df["order_date"].max() + pd.Timedelta(days=1)
rfm = (df.groupby("customer_id")
         .agg(recency=("order_date", lambda x: (snapshot_date - x.max()).days),
              frequency=("order_id", "nunique"),
              monetary=("net_amount", "sum"))
         .reset_index())

rfm["r_score"] = pd.qcut(rfm["recency"], 4, labels=[4, 3, 2, 1]).astype(int)
rfm["f_score"] = pd.qcut(rfm["frequency"].rank(method="first"), 4, labels=[1, 2, 3, 4]).astype(int)
rfm["m_score"] = pd.qcut(rfm["monetary"], 4, labels=[1, 2, 3, 4]).astype(int)
rfm["rfm_score"] = rfm["r_score"] + rfm["f_score"] + rfm["m_score"]


def segment_customer(row):
    if row["rfm_score"] >= 10:
        return "High-Value"
    elif row["rfm_score"] >= 7:
        return "Loyal"
    elif row["rfm_score"] >= 5:
        return "At-Risk"
    else:
        return "Low-Value"


rfm["segment"] = rfm.apply(segment_customer, axis=1)
rfm = rfm.merge(customers[["customer_id", "customer_name", "segment"]].rename(
    columns={"segment": "stated_segment"}), on="customer_id", how="left")
rfm.to_csv(OUT_DIR / "customer_rfm.csv", index=False)

# ---------------------------------------------------------------
# 8. TOP PRODUCTS / UNDERPERFORMING CATEGORIES
# ---------------------------------------------------------------
product_perf = (df.groupby(["product_id", "product_name", "category"])
                  .agg(revenue=("net_amount", "sum"),
                       units_sold=("quantity", "sum"),
                       margin=("margin_amount", "sum"))
                  .reset_index()
                  .sort_values("revenue", ascending=False))
product_perf.to_csv(OUT_DIR / "product_performance.csv", index=False)

category_perf = (df.groupby("category")
                    .agg(revenue=("net_amount", "sum"),
                         margin=("margin_amount", "sum"),
                         units_sold=("quantity", "sum"),
                         refund_rate=("is_refunded", "mean"))
                    .reset_index()
                    .sort_values("revenue", ascending=False))
category_perf["margin_pct"] = category_perf["margin"] / category_perf["revenue"]
category_perf.to_csv(OUT_DIR / "category_performance.csv", index=False)

# ---------------------------------------------------------------
# 9. REGIONAL PATTERNS
# ---------------------------------------------------------------
region_perf = (df.groupby("region")
                 .agg(revenue=("net_amount", "sum"),
                      orders=("order_id", "nunique"),
                      customers=("customer_id", "nunique"))
                 .reset_index()
                 .sort_values("revenue", ascending=False))
region_perf["aov"] = region_perf["revenue"] / region_perf["orders"]
region_perf.to_csv(OUT_DIR / "region_performance.csv", index=False)

# ---------------------------------------------------------------
# 10. QUICK PRINTED SUMMARY (for console / notebook use)
# ---------------------------------------------------------------
print("\n=== TOP 5 PRODUCTS BY REVENUE ===")
print(product_perf.head(5)[["product_name", "revenue", "units_sold"]].to_string(index=False))

print("\n=== CATEGORY PERFORMANCE (sorted by revenue) ===")
print(category_perf[["category", "revenue", "margin_pct", "refund_rate"]].to_string(index=False))

print("\n=== REGIONAL PERFORMANCE ===")
print(region_perf.to_string(index=False))

print("\n=== CUSTOMER SEGMENTS (RFM) ===")
print(rfm["segment"].value_counts())

print(f"\nAll output tables written to: {OUT_DIR}")

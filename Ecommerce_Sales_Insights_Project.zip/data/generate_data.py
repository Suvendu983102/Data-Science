"""
Synthetic E-commerce dataset generator.
Creates 4 raw tables that mimic a real e-commerce system:
  - customers.csv
  - products.csv
  - locations.csv
  - orders.csv   (order-line level, includes some dirty data on purpose)

Run: python generate_data.py
Output: CSVs written into ../data/
"""

import numpy as np
import pandas as pd
from faker import Faker
import random

random.seed(42)
np.random.seed(42)
fake = Faker()
Faker.seed(42)

N_CUSTOMERS = 1500
N_PRODUCTS = 200
N_LOCATIONS = 40
N_ORDER_LINES = 20000
START_DATE = pd.Timestamp("2024-01-01")
END_DATE = pd.Timestamp("2026-08-31")

CATEGORIES = {
    "Electronics": ["Headphones", "Smartwatch", "Bluetooth Speaker", "Power Bank", "Webcam"],
    "Home & Kitchen": ["Air Fryer", "Blender", "Cookware Set", "Vacuum Cleaner", "Table Lamp"],
    "Fashion": ["Sneakers", "Jacket", "Handbag", "Sunglasses", "Wrist Watch"],
    "Beauty": ["Face Serum", "Perfume", "Hair Dryer", "Makeup Kit", "Sunscreen"],
    "Sports": ["Yoga Mat", "Dumbbell Set", "Cycling Helmet", "Running Shoes", "Water Bottle"],
    "Books": ["Fiction Novel", "Self-Help Book", "Cookbook", "Biography", "Comic Set"],
}

# ---------- Locations ----------
regions = ["North", "South", "East", "West", "Central"]
locations = []
for i in range(N_LOCATIONS):
    locations.append({
        "location_id": f"LOC{i+1:03d}",
        "city": fake.city(),
        "state": fake.state(),
        "region": random.choice(regions),
    })
locations_df = pd.DataFrame(locations)

# ---------- Customers ----------
customers = []
for i in range(N_CUSTOMERS):
    signup_date = fake.date_between(start_date=START_DATE.date(), end_date=END_DATE.date())
    customers.append({
        "customer_id": f"CUST{i+1:05d}",
        "customer_name": fake.name(),
        "email": fake.email(),
        "signup_date": signup_date,
        "location_id": random.choice(locations_df["location_id"]),
        "segment": random.choices(["Regular", "Premium", "New"], weights=[0.55, 0.2, 0.25])[0],
    })
customers_df = pd.DataFrame(customers)

# ---------- Products ----------
products = []
pid = 1
for cat, items in CATEGORIES.items():
    for item in items:
        for variant in range(N_PRODUCTS // (len(CATEGORIES) * len(items)) + 1):
            if pid > N_PRODUCTS:
                break
            base_cost = round(np.random.uniform(5, 150), 2)
            margin_pct = np.random.uniform(0.15, 0.55)
            products.append({
                "product_id": f"PRD{pid:04d}",
                "product_name": f"{item} {random.choice(['Pro','Lite','Max','Plus','Basic'])}",
                # deliberately inconsistent category casing/spacing for cleaning practice
                "category": random.choice([cat, cat.upper(), f" {cat} "]),
                "unit_cost": base_cost,
                "unit_price": round(base_cost * (1 + margin_pct), 2),
            })
            pid += 1
products_df = pd.DataFrame(products[:N_PRODUCTS])

# ---------- Orders (order-line level) ----------
order_lines = []
customer_ids = customers_df["customer_id"].tolist()
product_ids = products_df["product_id"].tolist()
cust_signup = dict(zip(customers_df["customer_id"], pd.to_datetime(customers_df["signup_date"])))

# give some customers repeat-purchase behavior (skewed distribution)
purchase_weights = np.random.exponential(scale=1.5, size=len(customer_ids)) + 0.1

order_id_counter = 1
for i in range(N_ORDER_LINES):
    cust = random.choices(customer_ids, weights=purchase_weights, k=1)[0]
    signup = cust_signup[cust]
    order_date = fake.date_between(start_date=max(signup.date(), START_DATE.date()), end_date=END_DATE.date())
    prod = random.choice(product_ids)
    price = products_df.loc[products_df.product_id == prod, "unit_price"].values[0]
    qty = random.choices([1, 2, 3, 4, 5], weights=[0.6, 0.2, 0.1, 0.06, 0.04])[0]

    is_refund = random.random() < 0.04
    # inject some messiness: missing qty, duplicate rows, null customer occasionally
    row = {
        "order_id": f"ORD{order_id_counter:06d}",
        "order_date": order_date,
        "customer_id": cust if random.random() > 0.01 else None,
        "product_id": prod,
        "quantity": qty if random.random() > 0.02 else None,
        "unit_price": price,
        "is_refunded": is_refund,
    }
    order_lines.append(row)
    order_id_counter += 1

    # ~3% duplicate rows to simulate real dirty data
    if random.random() < 0.03:
        order_lines.append(row.copy())

orders_df = pd.DataFrame(order_lines)

# Save raw (dirty) data
locations_df.to_csv("/home/claude/ecommerce_project/data/locations.csv", index=False)
customers_df.to_csv("/home/claude/ecommerce_project/data/customers.csv", index=False)
products_df.to_csv("/home/claude/ecommerce_project/data/products.csv", index=False)
orders_df.to_csv("/home/claude/ecommerce_project/data/orders.csv", index=False)

print("Generated:")
print(f"  locations.csv  -> {len(locations_df)} rows")
print(f"  customers.csv  -> {len(customers_df)} rows")
print(f"  products.csv   -> {len(products_df)} rows")
print(f"  orders.csv     -> {len(orders_df)} rows (includes intentional dupes/nulls)")

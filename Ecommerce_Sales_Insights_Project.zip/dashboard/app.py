"""
E-commerce Sales & Customer Insights Dashboard
Run with:  streamlit run app.py
(Requires the analysis.py script to have been run first, so that
 /outputs/*.csv exist.)
"""

import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

OUT_DIR = Path(__file__).resolve().parent.parent / "outputs"

st.set_page_config(page_title="E-commerce Insights Dashboard", layout="wide")

# ---------------------------------------------------------------
# LOAD DATA
# ---------------------------------------------------------------
@st.cache_data
def load_data():
    df = pd.read_csv(OUT_DIR / "clean_orders.csv", parse_dates=["order_date"])
    kpis = pd.read_csv(OUT_DIR / "kpis.csv")
    monthly = pd.read_csv(OUT_DIR / "monthly_trend.csv", parse_dates=["order_month"])
    product_perf = pd.read_csv(OUT_DIR / "product_performance.csv")
    category_perf = pd.read_csv(OUT_DIR / "category_performance.csv")
    region_perf = pd.read_csv(OUT_DIR / "region_performance.csv")
    rfm = pd.read_csv(OUT_DIR / "customer_rfm.csv")
    return df, kpis, monthly, product_perf, category_perf, region_perf, rfm


df, kpis, monthly, product_perf, category_perf, region_perf, rfm = load_data()

# ---------------------------------------------------------------
# SIDEBAR FILTERS
# ---------------------------------------------------------------
st.sidebar.header("Filters")

min_date, max_date = df["order_date"].min(), df["order_date"].max()
date_range = st.sidebar.date_input("Order date range", (min_date, max_date),
                                    min_value=min_date, max_value=max_date)

regions_sel = st.sidebar.multiselect("Region", sorted(df["region"].dropna().unique()),
                                      default=sorted(df["region"].dropna().unique()))
categories_sel = st.sidebar.multiselect("Category", sorted(df["category"].dropna().unique()),
                                         default=sorted(df["category"].dropna().unique()))
segment_sel = st.sidebar.multiselect("Customer segment (RFM)", sorted(rfm["segment"].unique()),
                                      default=sorted(rfm["segment"].unique()))

# Apply filters
mask = (
    (df["order_date"] >= pd.to_datetime(date_range[0])) &
    (df["order_date"] <= pd.to_datetime(date_range[1])) &
    (df["region"].isin(regions_sel)) &
    (df["category"].isin(categories_sel)) &
    (df["customer_id"].isin(rfm[rfm["segment"].isin(segment_sel)]["customer_id"]))
)
fdf = df[mask]

# ---------------------------------------------------------------
# HEADER + KPI CARDS
# ---------------------------------------------------------------
st.title("🛒 E-commerce Sales & Customer Insights Dashboard")
st.caption("Filtered view based on sidebar selections")

total_revenue = fdf["net_amount"].sum()
total_orders = fdf["order_id"].nunique()
aov = total_revenue / total_orders if total_orders else 0
active_customers = fdf["customer_id"].nunique()
repeat_rate = (fdf.groupby("customer_id")["order_id"].nunique() > 1).mean() * 100 if active_customers else 0
margin_pct = (fdf["margin_amount"].sum() / total_revenue * 100) if total_revenue else 0

c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Revenue", f"${total_revenue:,.0f}")
c2.metric("Orders", f"{total_orders:,}")
c3.metric("Avg Order Value", f"${aov:,.2f}")
c4.metric("Repeat-Customer Rate", f"{repeat_rate:.1f}%")
c5.metric("Margin %", f"{margin_pct:.1f}%")

st.divider()

# ---------------------------------------------------------------
# MONTHLY TREND
# ---------------------------------------------------------------
st.subheader("📈 Monthly Revenue Trend")
monthly_f = (fdf.assign(order_month=fdf["order_date"].values.astype("datetime64[M]"))
                .groupby("order_month")
                .agg(revenue=("net_amount", "sum"), orders=("order_id", "nunique"))
                .reset_index())
fig_trend = px.line(monthly_f, x="order_month", y="revenue", markers=True,
                     title="Revenue by Month")
st.plotly_chart(fig_trend, use_container_width=True)

# ---------------------------------------------------------------
# TOP PRODUCTS + CATEGORY PERFORMANCE
# ---------------------------------------------------------------
col1, col2 = st.columns(2)

with col1:
    st.subheader("🏆 Top 10 Products by Revenue")
    top_products = (fdf.groupby("product_name")["net_amount"].sum()
                        .sort_values(ascending=False).head(10).reset_index())
    fig_prod = px.bar(top_products, x="net_amount", y="product_name", orientation="h",
                       labels={"net_amount": "Revenue", "product_name": ""})
    fig_prod.update_layout(yaxis={"categoryorder": "total ascending"})
    st.plotly_chart(fig_prod, use_container_width=True)

with col2:
    st.subheader("📦 Category Performance")
    cat_f = (fdf.groupby("category")
                .agg(revenue=("net_amount", "sum"), margin=("margin_amount", "sum"))
                .reset_index())
    cat_f["margin_pct"] = (cat_f["margin"] / cat_f["revenue"] * 100).round(1)
    fig_cat = px.bar(cat_f.sort_values("revenue"), x="revenue", y="category", orientation="h",
                      color="margin_pct", color_continuous_scale="RdYlGn",
                      labels={"revenue": "Revenue", "category": "", "margin_pct": "Margin %"})
    st.plotly_chart(fig_cat, use_container_width=True)

# ---------------------------------------------------------------
# REGIONAL PATTERNS
# ---------------------------------------------------------------
st.subheader("🗺️ Regional Performance")
region_f = (fdf.groupby("region")
               .agg(revenue=("net_amount", "sum"), orders=("order_id", "nunique"),
                    customers=("customer_id", "nunique"))
               .reset_index())
region_f["aov"] = region_f["revenue"] / region_f["orders"]
fig_region = px.bar(region_f.sort_values("revenue", ascending=False),
                     x="region", y="revenue", text_auto=".2s",
                     hover_data=["orders", "customers", "aov"])
st.plotly_chart(fig_region, use_container_width=True)

# ---------------------------------------------------------------
# CUSTOMER SEGMENTATION (RFM)
# ---------------------------------------------------------------
st.subheader("👥 Customer Segments (RFM)")
seg_counts = rfm[rfm["customer_id"].isin(fdf["customer_id"])]["segment"].value_counts().reset_index()
seg_counts.columns = ["segment", "customers"]
col3, col4 = st.columns([1, 2])
with col3:
    fig_seg = px.pie(seg_counts, names="segment", values="customers", hole=0.4)
    st.plotly_chart(fig_seg, use_container_width=True)
with col4:
    st.markdown("**High-value customers (top 10 by monetary value)**")
    hv = (rfm[rfm["customer_id"].isin(fdf["customer_id"])]
          .sort_values("monetary", ascending=False)
          .head(10)[["customer_name", "recency", "frequency", "monetary", "segment"]])
    st.dataframe(hv, use_container_width=True, hide_index=True)

st.divider()

# ---------------------------------------------------------------
# DATA-BACKED RECOMMENDATIONS
# ---------------------------------------------------------------
st.subheader("💡 Recommendations")
st.markdown("""
- **Double down on Beauty & Home/Kitchen** — highest revenue *and* healthy margin; prioritize
  inventory and ad spend here over lower-margin Fashion/Sports lines.
- **Investigate the "At-Risk" and "Low-Value" RFM segments** (roughly 40% of customers) with a
  win-back email campaign — even a modest reactivation lifts repeat-purchase rate meaningfully.
- **Regional expansion:** South and North regions drive the most revenue and highest customer
  counts — test increased marketing spend in East/West, which lag despite comparable AOV.
- **Refund hotspots:** Electronics and Books show the highest refund rates — worth a quality/
  description audit on those listings before scaling further.
- **Protect AOV:** consider a small free-shipping threshold just above the current AOV to
  nudge order sizes up.
""")

st.caption("Dashboard built with Streamlit + Plotly · Data refreshed from analysis.py outputs")
